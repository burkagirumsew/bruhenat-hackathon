# BRUH-ENAT HACKATHON 2026 - DIRECTADMIN DEPLOYMENT GUIDE

## Quick 2-Minute Deployment Steps

### Method 1: Upload the ZIP File (Fastest)
1. Log in to your **DirectAdmin Control Panel** (Yegara Host).
2. Go to **System Info & Files** -> **File Manager**.
3. Navigate into the **`public_html`** directory.
4. (Optional) Backup or delete any old files inside `public_html`.
5. Click **Upload Files** and upload **`biruh-enat-directadmin-final.zip`**.
6. Right-click or select the zip file and click **Extract**.
7. Ensure all extracted files are directly in `public_html` (not in a subfolder).
8. Visit your domain: `https://bruhenat.pro.et` (or your domain).

---

### Method 2: Upload Files Directly via FTP / File Manager
Upload the contents of this folder directly to `public_html`:
- `index.html`
- `ticket.html`
- `verify.html`
- `.htaccess`
- `admin/`
- `assets/`
- `css/`
- `js/`
- `api/`

---

### Supabase Database Setup
1. Log in to **https://supabase.com/dashboard/project/ieyzrrovmofjrzofldlq**.
2. Go to **SQL Editor** -> **New Query**.
3. Paste the contents of **`supabase_schema_and_policies.sql`** and click **Run**.

---

### Admin Login Credentials
- **URL:** `https://yourdomain.com/admin` (or `/admin/login`)
- **Email:** `admin@bruhenat-hackathon.org`
- **Password:** `AdminPassword2026!`
